'use strict';

module.exports = [
  './node_modules/normalize.css/normalize.css',
  './node_modules/animate.css/animate.min.css',
  './node_modules/remodal/dist/remodal-default-theme.css',
  './node_modules/remodal/dist/remodal.css',
  './node_modules/font-awesome/css/font-awesome.min.css',
  './node_modules/slick-carousel/slick/slick.css'
];
