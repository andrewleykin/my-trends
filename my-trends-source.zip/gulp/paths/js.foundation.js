'use strict';

module.exports = [
  './node_modules/jquery/dist/jquery.min.js',
  './node_modules/svg4everybody/dist/svg4everybody.legacy.min.js',
  './node_modules/remodal/dist/remodal.min.js',
  './node_modules/wowjs/dist/wow.min.js',
  './node_modules/slick-carousel/slick/slick.min.js'
];
