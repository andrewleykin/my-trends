'use strict';

module.exports = [
  './dev/static/js/app.js',
  './dev/static/js/libs/svg4everybody.js',
  './dev/static/js/libs/wowjs.js',
];